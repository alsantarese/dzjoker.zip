clear
#colors
w='\e[97m'
g='\033[1;92m'
r='\033[1;91m'
a='\033[1;94m'
b='\e[1;4m'
cyan='\033[1;36m'
green='\033[1;32m'
red='\033[1;31m'
yellow='\033[1;33m'
blue='\033[1;34m'
purple='\033[1;35m'
reset='\033[0m'
G='\e[110m'
G1='\e[101m'
o='\033[0m'
n=install
cd $HOME/dzjoker/.ngrok/
toilet -f mono12 -F gay "Ngrok"
echo -e "$green"
echo -e ""$red"[$reset"1"$red]$green OPEN PORT TCP"
echo -e ""$red"[$reset"2"$red]$green INSTALL NGROK"  $red"                    ["$w"00"$red"]"$red" ExIT"
echo -e ""$red"[$reset"3"$red]$green OPEN PORT HTTP" $red"                   ["$w"99"$red"]"$cyan" BaCk"
echo -e "$red"
read -p "Please Enter NuMbeR<<<<H>>>>:~# " ng

if [ "$ng" -eq "99"  ]; then
cd /$HOME/dzjoker/
./joker.sh
fi

if [ "$ng" -eq "00" ]; then
clear
exit
fi

tcp(){
echo -e "$green"
clear
figlet -f big "Open tcp"
read -p "PlEaSE EnTear PORT TCP====>>> " port
cd && ./ngrok tcp $port
echo -e "$red"
clear
figlet -f big "ERROR"
echo -e "Please download >>>>[NGROK]"
sleep 1
cd $HOME/dzjoker/.ngrok/
./ng.sh
}
if [ "$ng" -eq "1"  ]; then
	tcp
fi
########
d(){
echo -e "$green"
clear
figlet -f big "Do Ngrok"
read -p "PlEaSE EnTear Go Download====>>> " down
termux-open http://www.ngrok.com
echo -e "$green"
cp $HOME/payload5/.ngrok/ngrok $HOME
cd $HOME && chmod 777 ngrok
./ngrok --help
sleep 1
cd $HOME/dzjoker/.ngrok/
./ng.sh
}
if [ "$ng" -eq "2"  ]; then
d
fi
#######
htt(){
clear
echo -e "$green"
figlet -f big "OpenHttp"
read -p "PlEaSE EnTear PORT HTTP====>>> " port
cd && ./ngrok http $port
clear
figlet -f big "ERROR"
echo -e "Please download >>>>[NGROK]"
sleep 1
cd $HOME/dzjoker/.ngrok/
./ng.sh
}
if [ "$ng" -eq "3"  ]; then
htt
fi
