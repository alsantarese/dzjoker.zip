

#colors
w='\e[97m'
g='\033[1;92m'
r='\033[1;91m'
a='\033[1;94m'
b='\e[1;4m'
cyan='\033[1;36m'
green='\033[1;32m'
red='\033[1;31m'
yellow='\033[1;33m'
blue='\033[1;34m'
purple='\033[1;35m'
reset='\033[0m'
G='\e[110m'
G1='\e[101m'
o='\033[0m'
n=install
clear
cd /$HOME/dzjoker/.dos/

figlet -f big " A T TACK"
echo -e $red"["$w"1"$red"]"$w "Hedra" $red"                               ["$w"5"$red"]"$w "Tor"
sleep 0.1
echo -e $red"["$w"2"$red"]"$w" Black Hydra" $red"    ["$w"00"$red"]"$red" ExIT" $red"           ["$w"6"$red"]"$w "HashID"
sleep 0.1
echo -e $red"["$w"3"$red"]"$w" Cupp" $red"           ["$w"99"$red"]"$cyan" BaCk" $red"           ["$w"7"$red"]"$w "Xshell"
sleep 0.1
echo -e $red"["$w"4"$red"]"$w" InstaHack" $red"                           ["$w"8"$red"]"$w "HashBrute"

echo -e "$green"
read -p "Please Enter NumBeR}}}>>:~# " pa


if [ "$pa" -eq "99" ]; then
cd /$HOME/dzjoker/
./joker.sh
fi
if [ "$pa" -eq "00" ]; then
clear
exit
fi
############6666#

################
Hydra(){
echo -e "$purple"
figlet  -f big "   Hydra"
sleep 1
cd
pkg $n hydra -y
clear
echo -e "$blue"
figlet  -f big "Dz JoOkeR"
echo "Please Enter Back<<<"
read back

$back clear
cd /$HOME/dzjoker
./joker.sh

}

if [ "$pa" -eq "1"  ]; then
        Hydra
fi
##############
blackhydra(){
echo -e "$red"
figlet  -f big "Black HydrA"
sleep 1
cd
git clone https://github.com/Gameye98/Black-Hydra
clear
echo -e "$yellow"
figlet  -f big "Dz JoOkeR"
echo "Please Enter Back<<<"
read back

$back clear
cd /$HOME/dzjoker
./joker.sh

}

if [ "$pa" -eq "2"  ]; then
        blackhydra
fi
###############
cupp(){
echo -e "$red"
figlet  -f big "LIST Cupp"
sleep 1
cd
git clone https://github.com/Mebus/cupp
clear
echo -e "$yellow"
figlet  -f big "Dz JoOkeR"
echo "Please Enter Back<<<"
read back

$back clear
cd /$HOME/dzjoker
./joker.sh

}

if [ "$pa" -eq "3"  ]; then
        cupp
fi
###############
InstaHack(){
echo -e "$green"
figlet  -f big "InstaHack"
sleep 1
cd
git clone https://github.com/avramit/Instahack
clear
echo -e "$yellow"
figlet  -f big "Dz JoOkeR"
echo "Please Enter Back<<<"
read back

$back clear
cd /$HOME/dzjoker
./joker.sh

}

if [ "$pa" -eq "4"  ]; then
        InstaHack
fi
#################################
tor(){
echo -e "$purple"
figlet  -f big "  T  O  R  "
sleep 1
cd
pkg $n tor -y
clear
echo -e "$blue"
figlet  -f big "Dz JoOkeR"
echo "Please Enter Back<<<"
read back

$back clear
cd /$HOME/dzjoker
./joker.sh

}

if [ "$pa" -eq "5"  ]; then
        tor
fi
########################
########################
hash(){
echo -e "$green"
figlet  -f big "HASH.ID"
sleep 1
cd
git clone https://github.com/psypanda/hashID
clear
echo -e "$yellow"
figlet  -f big "Dz JoOkeR"
echo "Please Enter Back<<<"
read back

$back clear
cd /$HOME/dzjoker
./joker.sh

}

if [ "$pa" -eq "6"  ]; then
        hash
fi
########################
xshell(){
echo -e "$green"
figlet  -f big "X.SHELL"
sleep 1
cd
git clone https://github.com/netsarang/Xshell-ColorScheme
clear
echo -e "$yellow"
figlet  -f big "Dz JoOkeR"
echo "Please Enter Back<<<"
read back

$back clear
cd /$HOME/dzjoker
./joker.sh

}

if [ "$pa" -eq "7"  ]; then
        xshell
fi
###################
hashb(){
echo -e "$green"
figlet  -f big "HashBrute"
sleep 1
cd
git clone https://github.com/ForceBru/HashBrute
clear
echo -e "$yellow"
figlet  -f big "Dz JoOkeR"
echo "Please Enter Back<<<"
read back

$back clear
cd /$HOME/dzjoker
./joker.sh

}

if [ "$pa" -eq "8"  ]; then
        hashb
fi

##############
