


clear

#color
w='\e[97m'
g='\033[1;92m'
r='\033[1;91m'
a='\033[1;94m'
b='\e[1;4m'
cyan='\033[1;36m'
green='\033[1;32m'
red='\033[1;31m'
yellow='\033[1;33m'
blue='\033[1;34m'
purple='\033[1;35m'
reset='\033[0m'
G='\e[110m'
G1='\e[101m'
o='\033[0m'
n=install






cd $HOME/dzjoker/.wifi/


######()///
echo -e "$blue"
figlet -f big "WiFiHaCk"
sleep 0.1
echo -e $red"["$w"1"$red"]"$yellow "wifite" $red"                       ["$w"5"$red"]"$yellow "Dracnmap"
sleep 0.1
echo -e $red"["$w"2"$red"]"$yellow "wifite2" $red"      ["$w"00"$red"]"$red "ExIT" $red"      ["$w"6"$red"]"$yellow "FLuxion"
sleep 0.1
echo -e $red"["$w"3"$red"]"$yellow "websploit" $red"    ["$w"99"$red"]"$cyan "baCk" $red"      ["$w"7"$red"]"$yellow "wifiphisher"
sleep 0.1
echo -e $red"["$w"4"$red"]"$yellow "RouterS.." $red"                    ["$w"8"$red"]"$yellow "Aircrack-ng"

echo -e "$blue"
read -p "Please Enter NumBeR}}}>>:~# " wi



if [ "$wi" -eq "99" ]; then
cd /$HOME/dzjoker/
./joker.sh
fi
if [ "$wi" -eq "00" ]; then
exit
fi

###############
wifite(){
echo -e "$cyan"
figlet  -f big "  WIFITE"
sleep 1
cd
git clone https://github.com/derv82/wifite
clear
echo -e "$yellow"
figlet  -f big "B A CcK k"
echo -e "["$w"1"$red"]"$red "BaCk joker"
echo -e "["$w"2"$red"]"$red "BaCk Wifi"
echo -e "$cyan"
read -p "Please Enter NuMer Back<<<" back

}

if [ "$wi" -eq "1"  ]; then
        wifite
fi
if [ "$back" -eq "1"  ]; then
cd /$HOME/dzjoker/
./joker.sh
fi
if [ "$back" -eq "2"  ]; then
cd /$HOME/dzjoker/.wifi/
./wifi.sh
fi
#################
wifite2(){
echo -e "$red"
figlet  -f big " WIFITE 2"
sleep 1
cd
git clone https://github.com/derv82/wifite2
clear
echo -e "$yellow"
figlet  -f big "B A CcK k"
echo -e "["$w"1"$red"]"$red "BaCk joker"
echo -e "["$w"2"$red"]"$red "BaCk Wifi"
echo -e "$cyan"
read -p "Please Enter NuMer Back<<<" back

}

if [ "$wi" -eq "2"  ]; then
        wifite2
fi
if [ "$back" -eq "1"  ]; then
cd /$HOME/dzjoker/
./joker.sh
fi
if [ "$back" -eq "2"  ]; then
cd /$HOME/dzjoker/.wifi/
./wifi.sh
fi
########(((#
websploit(){
echo -e "$yellow"
figlet  -f big "Websploit"
sleep 1
cd
git clone https://github.com/Exploit-install/websploit
clear
echo -e "$yellow"
figlet  -f big "B A CcK k"
echo -e "["$w"1"$red"]"$red "BaCk joker"
echo -e "["$w"2"$red"]"$red "BaCk Wifi"
echo -e "$cyan"
read -p "Please Enter NuMer Back<<<" back

}

if [ "$wi" -eq "3"  ]; then
        websploit
fi
if [ "$back" -eq "1"  ]; then
cd /$HOME/dzjoker/
./joker.sh
fi
if [ "$back" -eq "2"  ]; then
cd /$HOME/dzjoker/.wifi/
./wifi.sh
fi
################
RouterS(){
echo -e "$red"
figlet  -f big "Router S"
sleep 1
cd
git clone https://github.com/threat9/routersploit
clear
echo -e "$yellow"
figlet  -f big "B A CcK k"
echo -e "["$w"1"$red"]"$red "BaCk joker"
echo -e "["$w"2"$red"]"$red "BaCk Wifi"
echo -e "$cyan"
read -p "Please Enter NuMer Back<<<" back

}

if [ "$wi" -eq "4"  ]; then
        RouterS
fi
if [ "$back" -eq "1"  ]; then
cd /$HOME/dzjoker/
./joker.sh
fi
if [ "$back" -eq "2"  ]; then
cd /$HOME/dzjoker/.wifi/
./wifi.sh
fi
###########33##3
dranc(){
echo -e "$red"
figlet  -f big "Dracnmap"
sleep 1
cd
git clone https://github.com/Screetsec/Dracnmap
clear
echo -e "$yellow"
figlet  -f big "B A CcK k"
echo -e "["$w"1"$red"]"$red "BaCk joker"
echo -e "["$w"2"$red"]"$red "BaCk Wifi"
echo -e "$cyan"
read -p "Please Enter NuMer Back<<<" back

}

if [ "$wi" -eq "5"  ]; then
        dranc
fi
if [ "$back" -eq "1"  ]; then
cd /$HOME/dzjoker/
./joker.sh
fi
if [ "$back" -eq "2"  ]; then
cd /$HOME/dzjoker/.wifi/
./wifi.sh
fi
###############
###############
FLuxion(){
echo -e "$red"
figlet  -f big "FLuxion"
sleep 1
cd
git clone https://github.com/FluxionNetwork/fluxion
clear
echo -e "$yellow"
figlet  -f big "B A CcK k"
echo -e "["$w"1"$red"]"$red "BaCk joker"
echo -e "["$w"2"$red"]"$red "BaCk Wifi"
echo -e "$cyan"
read -p "Please Enter NuMer Back<<<" back

}

if [ "$wi" -eq "6"  ]; then
        FLuxion
fi
if [ "$back" -eq "1"  ]; then
cd /$HOME/dzjoker/
./joker.sh
fi
if [ "$back" -eq "2"  ]; then
cd /$HOME/dzjoker/.wifi/
./wifi.sh
fi
#####################
wifiphisher(){
echo -e "$red"
figlet  -f big "wifiphisher"
sleep 1
cd
git clone https://github.com/wifiphisher/wifiphisher.git
clear
echo -e "$yellow"
figlet  -f big "B A CcK k"
echo -e "["$w"1"$red"]"$red "BaCk joker"
echo -e "["$w"2"$red"]"$red "BaCk Wifi"
echo -e "$cyan"
read -p "Please Enter NuMer Back<<<" back

}

if [ "$wi" -eq "7"  ]; then
        wifiphisher
fi
if [ "$back" -eq "1"  ]; then
cd /$HOME/dzjoker/
./joker.sh
fi
if [ "$back" -eq "2"  ]; then
cd /$HOME/dzjoker/.wifi/
./wifi.sh
fi
###########################3
aircrack(){
echo -e "$red"
figlet  -f big "AirCraCk"
sleep 1
cd
git clone https://github.com/aircrack-ng/aircrack-ng
clear
echo -e "$yellow"
figlet  -f big "B A CcK k"
echo -e "["$w"1"$red"]"$red "BaCk joker"
echo -e "["$w"2"$red"]"$red "BaCk Wifi"
echo -e "$cyan"
read -p "Please Enter NuMer Back<<<" back

}

if [ "$wi" -eq "8"  ]; then
        aircrack
fi
if [ "$back" -eq "1"  ]; then
cd /$HOME/dzjoker/
./joker.sh
fi
if [ "$back" -eq "2"  ]; then
cd /$HOME/dzjoker/.wifi/
./wifi.sh
fi
################
