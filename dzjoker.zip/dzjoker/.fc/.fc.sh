#!/bin/bash

#colors
w='\e[97m'
g='\033[1;92m'
r='\033[1;91m'
a='\033[1;94m'
b='\e[1;4m'
cyan='\033[1;36m'
green='\033[1;32m'
red='\033[1;31m'
yellow='\033[1;33m'
blue='\033[1;34m'
purple='\033[1;35m'                                                                                                     
reset='\033[0m'
G='\e[110m'
G1='\e[101m'                                                                                                            
o='\033[0m'
n=install

cd /$HOME/dzjoker/.fc/

####facebook
clear
echo -e "$cyan"
figlet -f big "FACEBOOK"

echo -e $red"["$w"1"$red"]"$green "fb.py"           $red"                        ["$w"6"$red"]"$green "weemam"
sleep 0.1
echo -e $red"["$w"2"$red"]"$green "fb_joker"    $red"       ["$w"00"$red"]"$red ExIT            $red"    ["$w"7"$red"]"$green "SocialFish"
sleep 0.1
echo -e $red"["$w"3"$red"]"$green "Facebook.pl"   $red"    ["$w"99"$red"]"$cyan BaCk                 $red"    ["$w"8"$red"]"$green "fbbrute"
sleep 0.1
echo -e $red"["$w"4"$red"]"$green "Cracker"                    $red"                      ["$w"9"$red"]"$green "MBF"
sleep 0.1
echo -e $red"["$w"5"$red"]"$green "Fbid"
echo -e "$yellow"
read -p "Please Enter NumBeR}}}>>:~# " fc

if [ "$fc" -eq "99" ]; then
cd /$HOME/dzjoker/
./joker.sh
fi
if [ "$fc" -eq "00" ]; then
clear
exit
fi
########################
fb(){
echo -e "$cyan"
figlet  -f big "Down fb.py"
sleep 1
cd
git clone https://github.com/emre/fb.py
clear
echo -e "$blue"
figlet  -f big "Dz JoOkeR"
echo "Please Enter Back<<<"
read back

$back clear
cd /$HOME/dzjoker
./joker.sh

}

if [ "$fc" -eq "1"  ]; then
        fb
fi
########################
fb_joker(){
echo -e "$blue"
figlet  -f big " fb_joker"
sleep 1
cd
git clone https://github.com/alsantarese/fb_joker
clear
echo -e "$purple"
figlet  -f big "Dz JoOkeR"
echo "Please Enter Back<<<"
read back

$back clear
cd /$HOME/dzjoker
./joker.sh

}

if [ "$fc" -eq "2"  ]; then
        fb_joker
fi
##################
fbpl(){
echo -e "$blue"
figlet  -f big " fb_joker"
sleep 1
cd
git clone https://github.com/bcattaneo/Facebook.pl
clear
echo -e "$purple"
figlet  -f big "Dz JoOkeR"
echo "Please Enter Back<<<"
read back

$back clear
cd /$HOME/dzjoker
./joker.sh

}

if [ "$fc" -eq "3"  ]; then
        fbpl
fi
####################
Cracker(){
echo -e "$red"
figlet  -f big " Cracker"
sleep 1
cd
git clone https://github.com/Ha3MrX/facebook-cracker
clear
echo -e "$yellow"
figlet  -f big "Dz JoOkeR"
echo "Please Enter Back<<<"
read back

$back clear
cd /$HOME/dzjoker
./joker.sh

}

if [ "$fc" -eq "4"  ]; then
        Cracker
fi
#####################
fbid(){
echo -e "$green"
figlet  -f big "Down fbid"
sleep 1
cd
git clone https://github.com/guelfoweb/fbid
clear
echo -e "$cyan"
figlet  -f big "Dz JoOkeR"
echo "Please Enter Back<<<"
read back

$back clear
cd /$HOME/dzjoker
./joker.sh

}

if [ "$fc" -eq "5"  ]; then
        fbid
fi
#_______:76؛7_7_--

wee(){
echo -e "$green"
figlet  -f big "WEEMAM"
sleep 1
cd
git clone https://github.com/evait-security/weeman
clear
echo -e "$cyan"
figlet  -f big "Dz JoOkeR"
echo "Please Enter Back<<<"
read back

$back clear
cd /$HOME/dzjoker
./joker.sh

}

if [ "$fc" -eq "6"  ]; then
        wee
fi
##############
soc(){
echo -e "$green"
figlet  -f big "Social.."
sleep 1
cd
git clone https://github.com/UndeadSec/SocialFish
clear
echo -e "$cyan"
figlet  -f big "Dz JoOkeR"
echo "Please Enter Back<<<"
read back

$back clear
cd /$HOME/dzjoker
./joker.sh

}

if [ "$fc" -eq "7"  ]; then
        soc
fi
#########--
fbbrute(){
echo -e "$green"
figlet  -f big "FBbRute"
sleep 1
cd
git clone https://github.com/HackerAdana/facebook-brute-force
clear
echo -e "$cyan"
figlet  -f big "Dz JoOkeR"
echo "Please Enter Back<<<"
read back

$back clear
cd /$HOME/dzjoker
./joker.sh

}

if [ "$fc" -eq "8"  ]; then
        fbbrute
fi
#################
mbf(){
echo -e "$green"
figlet  -f big " M B F"
sleep 1
cd
git clone https://github.com/YukersCreew/mbf
clear
echo -e "$cyan"
figlet  -f big "Dz JoOkeR"
echo "Please Enter Back<<<"
read back

$back clear
cd /$HOME/dzjoker
./joker.sh

}

if [ "$fc" -eq "9"  ]; then
        mbf
fi
