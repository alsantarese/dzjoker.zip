#!/bin/bash
#colors
w='\e[97m'
g='\033[1;92m'
r='\033[1;91m'
a='\033[1;94m'
b='\e[1;4m'
cyan='\033[1;36m'
green='\033[1;32m'
red='\033[1;31m'
yellow='\033[1;33m'
blue='\033[1;34m'
purple='\033[1;35m'
reset='\033[0m'
G='\e[110m'                                                                                           
G1='\e[101m'
o='\033[0m'                                                                                           
n=install
clear
cd /$HOME/dzjoker/.inf/
##########informa
echo -e "$cyan"
figlet -f big "Info...."
echo -e $red"["$w"1"$red"]"$cyan "Th3inspe.."         $red"                  ["$w"6"$red"]"$cyan EvilURL
sleep 0.1
echo -e $red"["$w"2"$red"]"$cyan "OSIF      "     $red"   ["$w"00"$red"]"$red ExIT    $red"     ["$w"7"$red"]"$cyan  Devploit
sleep 0.1
echo -e $red"["$w"3"$red"]"$cyan "Nmap"        $red"         ["$w"99"$red"]"$blue  BaCk      $red"     ["$w"8"$red"]"$cyan   Namechk
sleep 0.1
echo -e $red"["$w"4"$red"]"$cyan "Infoga"     $red"                      ["$w"9"$red"]"$cyan  sqlmap
sleep 0.1
echo -e $red"["$w"5"$red"]"$cyan "RED_HAWK"
echo -e "$cyan"
read -p "Please Enter NumBeR}}}>>:~# " inf
#################

Th3inspector(){
echo -e "$red"
figlet  -f big "Th3insp.."
sleep 1
cd
git clone https://github.com/Moham3dRiahi/Th3inspector
clear
echo -e "$yellow"
figlet  -f big "Dz JoOkeR"
echo "Please Enter Back<<<"
read back

$back clear
cd /$HOME/dzjoker
./joker.sh

}

if [ "$inf" -eq "1"  ]; then
        Th3inspector
fi
#################
osif(){
echo -e "$yellow"
figlet  -f big "Down OSIF"
sleep 1
cd
git clone https://github.com/CiKu370/OSIF
clear
echo -e "$green"
figlet  -f big "Dz JoOkeR"
echo "Please Enter Back<<<"
read back

$back clear
cd /$HOME/dzjoker
./joker.sh

}

if [ "$inf" -eq "2"  ]; then
        osif
fi
#################
Infoga(){
echo -e "$blue"
figlet  -f big "   Infoga"
sleep 1
cd
git clone https://github.com/m4ll0k/Infoga
clear
echo -e "$purple"
figlet  -f big "Dz JoOkeR"
echo "Please Enter Back<<<"
read back

$back clear
cd /$HOME/dzjoker
./joker.sh

}

if [ "$inf" -eq "4"  ]; then
        Infoga
fi
###################

###################
RED_HAWK(){
echo -e "$red"
figlet  -f big " RED_HAWK"
sleep 1
cd
git clone https://github.com/Tuhinshubhra/RED_HAWK
clear
echo -e "$yellow"
figlet  -f big "Dz JoOKR"
echo "Please Enter Back<<<"
read back

$back clear
cd /$HOME/dzjoker
./joker.sh

}

if [ "$inf" -eq "5"  ]; then
        RED_HAWK
fi
#
#################
evil(){
echo -e "$red"
figlet  -f big "EvilLURL"
sleep 1
cd
git clone https://github.com/UndeadSec/EvilURL
clear
echo -e "$yellow"
figlet  -f big "Dz JoOkeR"
echo "Please Enter Back<<<"
read back

$back clear
cd /$HOME/dzjoker
./joker.sh

}

if [ "$inf" -eq "6"  ]; then
        evil
fi
##################
dev(){
echo -e "$red"
figlet  -f big "DevPloit"
sleep 1
cd
git clone https://github.com/joker25000/Devploit
clear
echo -e "$yellow"
figlet  -f big "Dz JoOkeR"
echo "Please Enter Back<<<"
read back

$back clear
cd /$HOME/dzjoker
./joker.sh

}

if [ "$inf" -eq "7"  ]; then
        dev
fi
##############33
Namechk(){
echo -e "$red"
figlet  -f big "Namechk"
sleep 1
cd
git clone https://github.com/HA71/Namechk
clear
echo -e "$yellow"
figlet  -f big "Dz JoOkeR"
echo "Please Enter Back<<<"
read back

$back clear
cd /$HOME/dzjoker
./joker.sh

}

if [ "$inf" -eq "8"  ]; then
        Namechk

fi
############
############
sqlmap(){
echo -e "$red"
figlet  -f big "SQLMaP"
sleep 1
cd
git clone https://github.com/sqlmapproject/sqlmap
clear
echo -e "$yellow"
figlet  -f big "Dz JoOkeR"
echo "Please Enter Back<<<"
read back

$back clear
cd /$HOME/dzjoker
./joker.sh

}

if [ "$inf" -eq "9"  ]; then
        sqlmap
fi

#################
nmap(){
echo -e "$red"
figlet  -f big "   Nmap"
sleep 1
cd
pkg $n nmap -y
clear
cd /$HOME/dzjoker
./joker.sh

}

if [ "$" -eq "3"  ]; then
        nmap
fi
if [ "$inf" -eq "99" ]; then
cd /$HOME/dzjoker/
./joker.sh
fi

}
if [ "$inf" = "00" ]; then
clear
exit
clear
fi
#cd /$HOME/dzjoker
#./joker.sh
