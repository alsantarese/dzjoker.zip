#colors
w='\e[97m'
g='\033[1;92m'
r='\033[1;91m'                                                   
a='\033[1;94m'
b='\e[1;4m'
cyan='\033[1;36m'
green='\033[1;32m'
red='\033[1;31m'
yellow='\033[1;33m'
blue='\033[1;34m'
purple='\033[1;35m'
reset='\033[0m'
G='\e[110m'
G1='\e[101m'
o='\033[0m'
n=install
clear
cd /$HOME/dzjoker/.meta/
#
echo -e "$blue"
figlet -f big "Metasploit"
echo -e $red"["$w"1"$red"]"$blue "Tmux-Bunch"     $red"                      ["$w"5"$red"]"$blue "A-RAT"
sleep 0.1
echo -e $red"["$w"2"$red"]"$blue "msf"     $red"           ["$w"00"$red"]"$red "ExIT" $red"        ["$w"6"$red"]"$blue "commix"
sleep 0.1
echo -e $red"["$w"3"$red"]"$blue "msf 5.0.0" $red"     ["$w"99"$red"]"$cyan "BaCk" $red"        ["$w"7"$red"]"$blue "payload5"
sleep 0.1
echo -e $red"["$w"4"$red"]"$blue "error metas" $red"                     ["$w"8"$red"]"$blue "EasY_HaCk"
echo -e "$purple"
read -p "Please Enter NumBeR}}}>>:~# " meta

if [ "$meta" -eq "99" ]; then
cd /$HOME/dzjoker/
./joker.sh
fi
if [ "$meta" -eq "00" ]; then
clear
exit
fi
#####
####################################

####################################
commix(){
echo -e "$blue"
figlet  -f big "COMMIX"
sleep 1
cd
git clone https://github.com/commixproject/commix
clear
echo -e "$purple"
figlet  -f big "Dz JoOkeR"
echo "Please Enter Back<<<"
read back

$back clear
cd /$HOME/dzjoker
./joker.sh

}

if [ "$meta" -eq "6"  ]; then
        commix
fi
######################
############
######################
payload5(){
echo -e "$blue"            
figlet  -f big "PaYLoAD5"
sleep 1
cd
git clone https://github.com/payload5/payload5
clear
echo -e "$purple"
figlet  -f big "Dz JoOkeR"
echo "Please Enter Back<<<"
read back

$back clear
cd /$HOME/dzjoker
./joker.sh

}                                                                
if [ "$meta" -eq "7"  ]; then
        payload5
fi
###########################
###########################
easy(){
echo -e "$blue"
figlet  -f big "EasYHaCk"
sleep 1
cd
git clone https://github.com/sabri-zaki/EasY_HaCk
clear
echo -e "$purple"
figlet  -f big "Dz JoOkeR"
echo "Please Enter Back<<<"
read back

$back clear
cd /$HOME/dzjoker
./joker.sh

}

if [ "$meta" -eq "8"  ]; then
        easy
fi

#############3
arat(){
echo -e "$blue"
figlet  -f big "   A-RAT"
sleep 1
cd
git clone https://github.com/AhMyth/AhMyth-Android-RAT
clear
echo -e "$purple"
figlet  -f big "Dz JoOkeR"
echo "Please Enter Back<<<"
read back

$back clear
cd /$HOME/dzjoker
./joker.sh

}

if [ "$meta" -eq "5"  ]; then
        arat
fi
############3
#(###########
msf(){
echo -e "$red"
figlet  -f big "Down  msf"
sleep 1
cd
git clone https://github.com/Hax4us/Metasploit_termux
mv Metasploit_termux .Metasploit_termux
cd $HOME/.Metasploit_termux
chmod +x *
./metasploit.sh
clear
echo -e "$cyan"
figlet  -f big "Dz JoOkeR"
echo "Please Enter Back<<<"
read back

$back clear
cd /$HOME/dzjoker
./joker.sh

}

if [ "$meta" -eq "1"  ]; then
        msf
fi
###############                                                                                       msf5(){
echo -e "$green"                                                                                      figlet  -f 
big "  msf 5.0.0"

echo -e "$g+++++++++++++++>$p[Please Wait]$g<+++++$"
cd
git clone https://github.com/rapid7/metasploit-framework
bundle install

clear
echo -e "$g>>>>>>>>>>>>>$p[Please Wait]$g<<<<<<<<<"
gem install crass -v '1.0.4' --source 'https://rubygems.org/'
cd
cd metasploit-framework                            bundle update nokogiri
echo -e "$g>>>>>>>>>>>>$p[end Download metasploit]$"
sleep 1
clear
echo -e "$blue"
figlet  -f big "Dz JoOkeR"
echo "Please Enter Back<<<"
read back

$back clear
cd /$HOME/dzjoker
./joker.sh

}

if [ "$meta" -eq "2"  ]; then
        msf5
fi
##########(((
##########(((
errormsf(){
echo -e "$red"
figlet  -f big " Cracker"
sleep 1
cd
echo -e ">>>>>>>>>>>>)) please wait ((<<<<<<<<<<<<"
cd .msf
chmod +x *ll
sh .error.sh

clear
echo -e "$yellow"
figlet  -f big "Dz JoOkeR"
echo "Please Enter Back<<<"
read back

$back clear
cd /$HOME/dzjoker
./joker.sh

}

if [ "$meta" -eq "3"  ]; then
        errormsf
fi
################
