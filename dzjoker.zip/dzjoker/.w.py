import os
import random
import sys
import time
import socket

os.system('clear')
m = '\033[1;32m'
c = '\033[1;31m'
d = '\033[1;33m'
o = '\033[1;35m'
a = '\033[1;36m'
print(o)
def mengetik(s):
    for c in s + '\n':
        sys.stdout.write(c)
        sys.stdout.flush()
        time.sleep(random.random() * 0.1)
mengetik('Welcome To The Channel Prove YourSelF')
print(a)
mengetik('This is a script for a work that is not a password')
print(m)
mengetik('Subscribe to my channel ---}\033[1;33m www.youtube.com/c/ProveYourSelF2018')
print('\r')
print('\033[1;31m=============================================================================')
os.system('figlet "                  Mc Doda" | lolcat -F 30')
print('\033[1;31m=============================================================================')
print(m)
mengetik('Type In The Name List Any Example Name ---> \033[1;33mpassword.txt \033[1;32m<---')
print('\r\n')
aaa=input('\033[1;33mEntre Name List : \033[1;32m')
os.system('clear')
print(d)
mengetik('Follow The Instructions \033[1;31m!')
print('\r')
print('\033[1;31m=============================================================================')
os.system('figlet "     Prove YourSelF" |lolcat -F 20')
print('\033[1;31m=============================================================================')
print(c)
mengetik('1-\033[1;32m Now Write In Each Number Name Or Numbers To Guess Them')
print(c)
mengetik('2-\033[1;33m Then After Typing In Each Number Press Enter')
print(c)
mengetik('3-\033[1;35m After the completion you can save not the password')
print(c)
mengetik('4-\033[1;36m By Writing --->\033[1;32m save \033[1;36m<--- And Pressing Enter')
print('\r\n')
print('\033[1;32mBy : Prove YourSelF')
print('\033[1;31m-\033[1;32m'*77)
file=open(aaa,'w')
aa=set([])
oio=set([])
#iio=set([112233,332211,000,445566,'$'*1,'$'*2,'$'*3,'@'*1,'@'*2,'@'*3,'€'*1,'€'*2,'€'*3,'&'*1,'&'*2,'&'*3,'¥'*1,'¥'*2,'¥'*3,'*'*1,'*'*2,'*'*3,'+'*1,'+'*2,'+'*3])
kk=1
while True :
    b=input('Number {} : \033[1;33m'.format(kk))
    if b=='save' :
        file.close()
        qq=open(aaa, 'r' )
        ll=len(qq.readlines())
        print('\033[1;31m')
        print('-'*77)
        print('\033[1;36m   >>>>>>>>>>>>>>>>>> \033[1;35m{}\033[1;32m Passwords in \033[1;36m---> \033[1;33m{} \033[1;36m<<<<<<<<<<<<<<<<<<'.format(ll, aaa))
        print('\033[1;31m-'*77)
        print('\r')
        break ;
    aa.add(b)
    for i in aa:
        if len(i) >= 6 and i not in oio :
            oio.add(i)
            file.write(i)
            file.write('\n')
            #for o in iio:
             #   uau='{}{}'.format(i,o)
              #  ubu='{}{}{}'.format(o,i,o)
               # ucu='{}{}{} '.format(i,o,i)
                #if len(uau)>= 6:
                   # file.write(uau)
                  #  file.write('\n')
               # if len(ubu) >= 6 and ubu != uau :
                   # file.write(ubu)
                   # file.write('\n')
                #if len(ucu) >= 6 and ucu != uau and ucu != ubu:
                  #  file.write(ucu)
                  #  file.write('\n')

        c=b+i
        d=i+b
        if len(c) >= 6 :
            file.write(c)
            file.write('\n')
        if c != d and len(d) >= 6:
            file.write(d)
            file.write('\n')
    kk=int(kk)+1
    print('\033[1;31m-\033[1;32m'*77)
