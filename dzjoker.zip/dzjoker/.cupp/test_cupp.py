#!/usr/bin/env python3

import unittest
from cupp3 import *

class TestCupp3(unittest.TestCase):
    def setUp(self):
        read_config()

    def test_ftp_download(self):
        pass

    def test_parser(self):
        pass

if __name__ == '__main__':
    unittest.main()
