def kk(t):
   import sys, time
   for txt in t + "\n":
        sys.stdout.write(txt)
        sys.stdout.flush()
        time.sleep(9. / 240)
f = "\033[1;31m[\033[0m00\033[1;31m] Exit\033[1;35m        \033[1;31m[\033[0m99\033[1;31m] \033[1;36mFACEBOOK   \033[1;31m[\033[0m88\033[1;31m] YouTube"
y = "\033[1;31m[\033[0m55\033[1;31m]\033[1;36mUPDATE       \033[0mBy~:Mhammed Hanfy \033[1;32mdzjoker_V.2.0"
kk(f)
kk(y)
